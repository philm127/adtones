﻿using EFMVC.Data;
using EFMVC.ProvisioningModel;
using Microsoft.AspNet.SignalR;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EFMVC.Web.Hubs
{
    public class AdDetailHub : Hub
    {
        public void LetsChat(string Cl_Name, string Cl_Message)
        {
            Clients.All.NewMessage(Cl_Name, Cl_Message);
           // Clients.All.Testing(Cl_Name, Cl_Message);
        }

        public void GetAdsName(string requestFormat)
        {
           
        
            try
            {
                var header = requestFormat.Substring(0, 14);
                var userAdName = header;
                // var userAdName = "ad100000567890";
                EFMVCDataContex db = new EFMVCDataContex();

                #region SQLServer
                //var userAdName = "Ad not Found";
                //var userProfile = db.Userprofiles.Where(s => s.MSISDN == mobile).FirstOrDefault();
                //if (userProfile != null)
                //{
                //    var userProfileId = userProfile.UserProfileId;
                //    var userprofileAdvert = db.UserProfileAdvertsReceived.Where(s => s.UserProfileId == userProfileId).OrderByDescending(s => s.AddedDate).FirstOrDefault();
                //    if(userprofileAdvert != null)
                //    {
                //         userAdName = userprofileAdvert.AdvertName == null? "Test Ad": userprofileAdvert.AdvertName;
                //        Clients.All.AdName(userAdName);
                //    }
                //    else
                //    {
                //        Clients.All.AdName(userAdName);
                //    }
                //}
                //else
                //{
                //    Clients.All.AdName(userAdName);
                //}
                #endregion

                #region Request Parameter
                //Request Parameter
                //------------
                //ad1000005678900000000044798000000200000000447980720251#
                //ad1 - IP ID
                //00000 - Space
                //56789 - Message ID
                //0 - CMD
                //00000000 - Space
                //447980720250 - Caller ID
                //00000000 - Space
                //447980720251 - Called ID
                //# - End Flag
                #endregion

                #region Response Parameter
                //Response Result
                //----------------
                //ad100000567890xxxxxxxxxxxxxxxxxabc0#
                //ad1 - IP ID
                //00000 - Space
                //56789 - Message ID
                //0 - CMD
                //xxxxxxxxxxxxxxxxxabc - AdName
                //0 - Result (O:Success, 1:Fail)
                //# - End Flag
                #endregion

                // var split = requestFormat.Split(new[] { "00000000" }, StringSplitOptions.None);
                var mobileNumber = requestFormat.Substring(22, 12);
                string externalServerConnString = ConfigurationManager.AppSettings["externalserverconnectionstring"];

                bool isExist =  IsLookUptable(mobileNumber, externalServerConnString);
               
                if(isExist)
                {
                    using (MySqlConnection conn = new MySqlConnection(externalServerConnString)) //External Server Connection
                    {
                        using (MySqlCommand cmd = new MySqlCommand("get_ad_name", conn))
                        {
                            cmd.CommandTimeout = 3600;
                            cmd.Parameters.Add(new MySqlParameter("phonenumber", mobileNumber));
                            cmd.CommandType = CommandType.StoredProcedure;
                            conn.Open();

                            MySqlDataReader dr = cmd.ExecuteReader();
                            while (dr.Read())
                            {
                                var adDetail = Convert.ToString(dr["adname"]);
                                if (adDetail == "NoAd")
                                {
                                    userAdName = userAdName + adDetail + "1#";
                                    Clients.All.AdName(userAdName);
                                }
                                else
                                {
                                    var fileName = userAdName + adDetail + "0#";
                                    Clients.All.AdName(fileName);
                                }
                            }
                            conn.Close();
                        }
                    }
                }
                else
                {
                    userAdName = userAdName + "NoAdd1#";
                    Clients.All.AdName(userAdName);
                }
              

                #region FromLocalDB
                //var mysqldb = new arthar_addcache_provisioningEntities4();
                //var bucketData = mysqldb.BUCKETs.Where(s => s.MSISDN == mobileNumber).OrderByDescending(s => s.ID);
                //if (bucketData != null)
                //{
                //    var bucketId = bucketData.FirstOrDefault().ID;
                //    var bucketItemData = mysqldb.BUCKET_ITEM.Where(s => s.BUCKET_ID == bucketId && s.ADD_STATE_ID == 2).OrderByDescending(s => s.ID); // Add condition AddStateID = 2(Play Add) 
                //    if (bucketItemData != null)
                //    {
                //        var fileName = userAdName + bucketItemData.FirstOrDefault().MEDIA_URL + "0#";
                //        Clients.All.AdName(fileName);
                //    }
                //    else
                //    {
                //        userAdName = userAdName + "NoAdd1#";
                //        Clients.Caller.AdName(userAdName);
                //    }

                //}
                //else
                //{
                //    userAdName = userAdName + "NoAdd1#";
                //    Clients.All.AdName(userAdName);
                //}
                #endregion

            }
            catch (Exception ex)
            {
                var userAdName = "ad100000567890NoAdd1#";
                Clients.All.AdName(userAdName);
            }

        }

        private bool IsLookUptable(string mobileNumber, string externalServerConnString)
        {          
            using (MySqlConnection conn = new MySqlConnection(externalServerConnString)) //External Server Connection
            {
                using (MySqlCommand cmd = new MySqlCommand("number_exist_on_lookup_table", conn))
                {
                    cmd.CommandTimeout = 3600;
                    cmd.Parameters.Add(new MySqlParameter("phonenumber", mobileNumber));
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    MySqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        conn.Close();
                        return true;                       
                    }                    
                    conn.Close();
                    return false;
                }
            }
        }
    }
}