﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EFMVC.Web.Core.ActionFilters;
using EFMVC.Web.Helpers;
using EFMVC.Data.Repositories;
using EFMVC.CommandProcessor.Dispatcher;
using EFMVC.Web.Areas.Admin.Models;
using EFMVC.Web.Areas.Admin.SearchClass;
using EFMVC.Model;
using EFMVC.Web.ViewModels;
using AutoMapper;
using EFMVC.Web.Common;
using EFMVC.Domain.Commands;
using EFMVC.CommandProcessor.Command;
using EFMVC.Web.Areas.UsersAdmin.Models;
using EFMVC.Domain.CountryConnectionString;
using EFMVC.Data;
using EFMVC.Web.Models;

namespace EFMVC.Web.Areas.Admin.Controllers
{

    [CompressResponse]
    [Authorize(Roles = "Admin")]
    [AdminRequired]
    [RouteArea("Admin")]
    [RoutePrefix("Campaign")]
    public class CampaignController : Controller
    {
        //
        // GET: /Admin/Campaign/

        //
        // GET: /Admin/Advert/

        /// <summary>
        /// The _advert repository
        /// </summary>
        private readonly IAdvertRepository _advertRepository;

        /// <summary>
        /// The _user repository
        /// </summary>
        private readonly IUserRepository _userRepository;

        /// <summary>
        /// The _client repository
        /// </summary>
        private readonly IClientRepository _clientRepository;

        /// <summary>
        /// The _profile repository
        /// </summary>
        private readonly ICampaignProfileRepository _profileRepository;

        /// <summary>
        /// The _user repository
        /// </summary>
        private readonly IQuestionRepository _questionRepository;
        /// <summary>
        /// The _command bus
        /// </summary>
        private readonly ICommandBus _commandBus;

        /// <summary>
        /// The _campaign advert repository
        /// </summary>
        private readonly ICampaignAdvertRepository _campaignAdvertRepository;
        public CampaignController(ICommandBus commandBus, IAdvertRepository advertRepository, IUserRepository userRepository, IClientRepository clientRepository, ICampaignProfileRepository profileRepository, ICampaignAdvertRepository campaignAdvertRepository, IQuestionRepository questionRepository)
        {
            _commandBus = commandBus;
            _advertRepository = advertRepository;
            _userRepository = userRepository;
            _clientRepository = clientRepository;
            _profileRepository = profileRepository;
            _campaignAdvertRepository = campaignAdvertRepository;
            _questionRepository = questionRepository;
        }

        [Route("Index")]
        [Route("{userId}/{campaignId}")]
        public ActionResult Index(int? userId, int? campaignId)
        {
            //List<CampaignAdminResult> _result = GetCampaignResult(userId, campaignId);

            Session["UserID"] = userId;
            Session["CampaignID"] = campaignId;

            FillUserDropdown(userId);
            FillClientDropdown();
            FillAdvertDropdown();
            FillCampaignStatus(userId);

            ViewBag.SearchResult = false;
            List<CampaignAdminResult> _result = new List<CampaignAdminResult>();

            //IEnumerable<CampaignProfile> campaignProfiles = _profileRepository.GetAll();
            //IEnumerable<CampaignProfileFormModel> campaignProfileFormModels =
            //    Mapper.Map<IEnumerable<CampaignProfile>, IEnumerable<CampaignProfileFormModel>>(campaignProfiles);
            //FillCampaignDropdown(campaignProfileFormModels);

            var campaigndropdown = _profileRepository.GetAll().Select(top => new
            {
                CampaignName = top.CampaignName,
                CampaignProfileId = top.CampaignProfileId
            }).ToList();
            ViewBag.campaigns = new MultiSelectList(campaigndropdown, "CampaignProfileId", "CampaignName");

            CampaignAdminFilter _filterCritearea = new CampaignAdminFilter();
            return View(Tuple.Create(_result, _filterCritearea));
        }

        [HttpPost]
        public JsonResult LoadData(DTParameters param)
        {
            try
            {
                List<CampaignAdminResult> _result = new List<CampaignAdminResult>();

                IEnumerable<CampaignProfileFormModel> campaignProfileFormModels = null;
                IEnumerable<CampaignProfile> campaignProfiles = null;

                ViewBag.SearchResult = false;
                var cnt = 10;
                int userId = 0;

                bool searchValue = false;
                List<String> columnSearch = new List<string>();

                foreach (var col in param.Columns)
                {
                    columnSearch.Add(col.Search.Value);
                    if (!string.IsNullOrEmpty(col.Search.Value) && col.Search.Value != "null")
                        searchValue = true;
                }

                if (searchValue == true)
                {
                    #region Search Functionality
                    int[] UserId = new int[cnt];
                    int[] ClientId = new int[cnt];
                    int[] CampaignId = new int[cnt];
                    int[] AdvertId = new int[cnt];
                    int[] CampaignStatusId = new int[cnt];
                    DateTime fromdate = new DateTime();
                    DateTime todate = new DateTime();
                    if (!String.IsNullOrEmpty(columnSearch[0]))
                    {
                        if (columnSearch[0] != "null")
                        {
                            UserId = columnSearch[0].Split(',').Select(int.Parse).ToArray();
                        }
                        else
                        {
                            columnSearch[0] = null;
                        }
                    }

                    if (!String.IsNullOrEmpty(columnSearch[1]))
                    {
                        if (columnSearch[1] != "null")
                        {
                            ClientId = columnSearch[1].Split(',').Select(int.Parse).ToArray();
                        }
                        else
                        {
                            columnSearch[1] = null;
                        }
                    }

                    if (!String.IsNullOrEmpty(columnSearch[2]))
                    {
                        if (columnSearch[2] != "null")
                        {
                            CampaignId = columnSearch[2].Split(',').Select(int.Parse).ToArray();
                        }
                        else
                        {
                            columnSearch[2] = null;
                        }
                    }

                    if (!String.IsNullOrEmpty(columnSearch[3]))
                    {
                        if (columnSearch[3] != "null")
                        {
                            AdvertId = columnSearch[3].Split(',').Select(int.Parse).ToArray();
                        }
                        else
                        {
                            columnSearch[3] = null;
                        }
                    }

                    if (!String.IsNullOrEmpty(columnSearch[4]))
                    {
                        if (columnSearch[4] != "null")
                        {
                            CampaignStatusId = columnSearch[4].Split(',').Select(int.Parse).ToArray();
                        }
                        else
                        {
                            columnSearch[4] = null;
                        }
                    }

                    if (!String.IsNullOrEmpty(columnSearch[5]))
                    {
                        if (columnSearch[5] != "null")
                        {
                            var data = columnSearch[5].Split(',').ToArray();
                            fromdate = Convert.ToDateTime(data[0]);
                            todate = Convert.ToDateTime(data[1]);
                        }
                        else
                        {
                            columnSearch[5] = null;

                        }
                    }

                    campaignProfiles = _profileRepository.GetMany(top => (UserId.Contains(top.UserId)) || (ClientId.Contains(top.ClientId)) ||
                   (AdvertId.Contains(top.CampaignAdverts.FirstOrDefault().AdvertId)) || (CampaignId.Contains(top.CampaignProfileId)) || (CampaignStatusId.Contains(top.Status))
                   || ((top.CreatedDateTime >= fromdate && top.CreatedDateTime <= todate))
                   ).OrderByDescending(top => top.CreatedDateTime).Skip(param.Start)
                                               .Take(param.Length);
                    //campaignProfileFormModels =
                    //    Mapper.Map<IEnumerable<CampaignProfile>, IEnumerable<CampaignProfileFormModel>>(campaignProfiles);
                    #endregion

                }
                else
                {
                    campaignProfiles = _profileRepository.GetAll().OrderByDescending(top => top.CreatedDateTime).Skip(param.Start)
                                                 .Take(param.Length); 



                    if (campaignProfiles.Count() >= 10)
                        cnt = _profileRepository.GetAll().Count();
                    //campaignProfileFormModels =
                    //    Mapper.Map<IEnumerable<CampaignProfile>, IEnumerable<CampaignProfileFormModel>>(campaignProfiles);
                }

                if (Session["UserID"] != null)
                {
                    int uId = (int)Session["UserID"];
                    campaignProfiles = _profileRepository.GetMany(top => top.UserId == uId).OrderByDescending(top => top.CreatedDateTime);
                    if (campaignProfiles.Count() > 10)
                        cnt = campaignProfiles.Count();
                }
                if (Session["CampaignID"] != null)
                {
                    int campId = (int)Session["CampaignID"];
                    campaignProfiles = _profileRepository.GetMany(top => top.CampaignProfileId == campId).OrderByDescending(top => top.CreatedDateTime);
                    if (campaignProfiles.Count() > 10)
                        cnt = campaignProfiles.Count();
                }
                //foreach (var item in campaignProfileFormModels)
                foreach (var item in campaignProfiles)
                {
                    //calculate average bid that has status Played.

                    IEnumerable<CampaignAuditFormModel> CampaignAuditData = null;
                    var play = Convert.ToString(CampaignAuditStatus.Played).ToLower();
                    var CountryID = _profileRepository.Get(x => (x.Status != 5) && x.CampaignProfileId == item.CampaignProfileId).CountryId;
                    var ConnString = ConnectionString.GetConnectionString(CountryID);


                    double totalbidval = 0;
                    double totalspend = 0;
                    double SMSCost = 0;
                    double EmailCost = 0;

                    if (!string.IsNullOrEmpty(ConnString))
                    {
                        EFMVCDataContex db = new EFMVCDataContex(ConnString);
                        CampaignAuditData = db.CampaignAudits.Where(top => top.Status.ToLower() == play && top.PlayLengthTicks > 6000 && top.CampaignProfileId == item.CampaignProfileId)
                                            .Select(s => new CampaignAuditFormModel { BidValue = s.BidValue, SMSCost = s.SMSCost, EmailCost = s.EmailCost });
                    }
                    else
                    {
                        EFMVCDataContex db = new EFMVCDataContex();
                        CampaignAuditData = db.CampaignAudits.Where(top => top.Status.ToLower() == play && top.PlayLengthTicks > 6000 && top.CampaignProfileId == item.CampaignProfileId)
                                           .Select(s => new CampaignAuditFormModel { BidValue = s.BidValue, SMSCost = s.SMSCost, EmailCost = s.EmailCost });
                    }
                    //var finaltotalplays = item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Count();

                    var finaltotalplays = CampaignAuditData.Count();

                    if (finaltotalplays > 0)
                    {
                        totalbidval = totalbidval + Convert.ToDouble(CampaignAuditData.Average(d1 => d1.BidValue));
                        totalspend = totalspend + CampaignAuditData.Sum(top => top.BidValue);
                        SMSCost = SMSCost + CampaignAuditData.Sum(d1 => d1.SMSCost);
                        EmailCost = EmailCost + CampaignAuditData.Sum(d1 => d1.EmailCost);
                        totalspend = totalspend + SMSCost + EmailCost;
                    }
                    var advertdetails = item.CampaignAdverts.Where(top => top.CampaignProfileId == item.CampaignProfileId).FirstOrDefault();
                    string advertname = string.Empty;
                    var advertId = 0;
                    if (advertdetails != null)
                    {

                        advertname = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertName;
                        advertId = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertId;
                    }
                    else
                    {
                        advertname = "-";
                        advertId = 0;
                    }
                    //_result.Add(new CampaignAdminResult { CampaignProfileId = item.CampaignProfileId, CampaignName = item.CampaignName, AdvertId = advertId, AdvertName = advertname, ClientId = item.ClientId, ClientName = item.Client.Name, CreatedDateTime = item.CreatedDateTime, DisplayCreatedDateTime = item.CreatedDateTime.ToString("dd/MM/yyyy"), Email = item.User.Email, UserId = item.UserId, UserName = item.User.FirstName + " " + item.User.LastName, finaltotalplays = finaltotalplays, FundsAvailable = Convert.ToDecimal(item.TotalBudget) - Convert.ToDecimal(totalspend), Status = item.Status, totalaveragebid = Convert.ToDecimal(totalbidval), TotalBudget = item.TotalBudget, totalspend = Convert.ToDecimal(totalspend), TicketCount = _questionRepository.Count(top => top.UserId == userId && top.CampaignProfileId == item.CampaignProfileId) });


                    _result.Add(new CampaignAdminResult
                    {
                        CampaignProfileId = item.CampaignProfileId,
                        Status = item.Status,
                        UserId = item.UserId,
                        Email = item.User.Email,
                        UserName = item.User.FirstName + " " + item.User.LastName,
                        ClientId = item.ClientId,
                        ClientName = item.Client.Name,
                        CampaignName =  item.CampaignName,
                        AdvertId = advertId,
                        AdvertName = advertname,
                        finaltotalplays = finaltotalplays,
                        TotalBudget = item.TotalBudget,
                        totalspend = Convert.ToDecimal(totalspend),
                        FundsAvailable = Convert.ToDecimal(item.TotalBudget) - Convert.ToDecimal(totalspend),
                        totalaveragebid = Convert.ToDecimal(totalbidval),
                        CreatedDateTime = item.CreatedDateTime,
                        DisplayCreatedDateTime = item.CreatedDateTime.ToString("dd/MM/yyyy"),                         
                        TicketCount = _questionRepository.Count(top => top.UserId == userId && top.CampaignProfileId == item.CampaignProfileId)
                    });
                    
                    
                    
                    
                    //double totalbidval = 0;
                    //double totalspend = 0;
                    //double SMSCost = 0;
                    //double EmailCost = 0;
                    //var finaltotalplays = item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Count();

                    //if(finaltotalplays > 0)
                    //{
                    //    totalbidval = totalbidval + Convert.ToDouble(item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Average(d1 => d1.BidValue));
                    //    totalspend = totalspend + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(top => top.BidValue);
                    //    SMSCost = SMSCost + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(d1 => d1.SMSCost);
                    //    EmailCost = EmailCost + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(d1 => d1.EmailCost);
                    //    totalspend = totalspend + SMSCost + EmailCost;
                    //}
                    //var advertdetails = item.CampaignAdverts.Where(top => top.CampaignProfileId == item.CampaignProfileId).FirstOrDefault();
                    //string advertname = string.Empty;
                    //var advertId = 0;
                    //if (advertdetails != null)
                    //{

                    //    advertname = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertName;
                    //    advertId = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertId;
                    //}
                    //else
                    //{
                    //    advertname = "-";
                    //    advertId = 0;
                    //}
                    // _result.Add(new CampaignAdminResult { CampaignProfileId = item.CampaignProfileId, CampaignName = item.CampaignName, AdvertId = advertId, AdvertName = advertname, ClientId = item.ClientId, ClientName = item.Client.Name, CreatedDateTime = item.CreatedDateTime, DisplayCreatedDateTime = item.CreatedDateTime.ToString("dd/MM/yyyy"), Email = item.User.Email, UserId = item.UserId, UserName = item.User.FirstName + " " + item.User.LastName, finaltotalplays = finaltotalplays, FundsAvailable = Convert.ToDecimal(item.TotalBudget) - Convert.ToDecimal(totalspend), Status = item.Status, totalaveragebid = Convert.ToDecimal(totalbidval), TotalBudget = item.TotalBudget, totalspend = Convert.ToDecimal(totalspend), TicketCount = _questionRepository.Count(top => top.UserId == userId && top.CampaignProfileId == item.CampaignProfileId) });

                }
                Session["UserID"] = null;
                Session["CampaignID"] = null;

                DTResult<CampaignAdminResult> result = new DTResult<CampaignAdminResult>
                {
                    draw = param.Draw,
                    data = _result,
                    recordsFiltered = cnt,
                    recordsTotal = cnt
                };

                return Json(result);

            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }


        private List<CampaignAdminResult> GetCampaignResult(int? userId, int? campaignId)
        {
            List<CampaignAdminResult> _result = new List<CampaignAdminResult>();
            IEnumerable<CampaignProfile> campaignProfiles = _profileRepository.GetAll();
            IEnumerable<CampaignProfileFormModel> campaignProfileFormModels =
                Mapper.Map<IEnumerable<CampaignProfile>, IEnumerable<CampaignProfileFormModel>>(campaignProfiles);
            campaignProfileFormModels = campaignProfileFormModels.OrderByDescending(top => top.CreatedDateTime);
            FillCampaignDropdown(campaignProfileFormModels);
            if (userId != null)
            {
                campaignProfileFormModels = campaignProfileFormModels.Where(top => top.UserId == userId);
            }
            if (campaignId != null)
            {
                campaignProfileFormModels = campaignProfileFormModels.Where(top => top.CampaignProfileId == campaignId);
            }
            foreach (var item in campaignProfileFormModels)
            {
                //calculate average bid that has status Played.
                var ticketCount = 0;
                double totalbidval = 0;
                double totalspend = 0;
                double SMSCost = 0;
                double EmailCost = 0;
                var finaltotalplays = item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Count();

                //caculate the AverageBid field
                if (item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Count() > 0)
                {
                    totalbidval = totalbidval + Convert.ToDouble(item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Average(d1 => d1.BidValue));
                }
                //cauculate total  spend that has status Played.
                if (item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Count() > 0)
                {
                    totalspend = totalspend + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(top => top.BidValue);
                    SMSCost = SMSCost + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(d1 => d1.SMSCost);
                    EmailCost = EmailCost + item.CampaignAudits.Where(top => top.Status.ToLower() == Convert.ToString(CampaignAuditStatus.Played).ToLower() && top.PlayLengthTicks > 6000).Sum(d1 => d1.EmailCost);
                    totalspend = totalspend + SMSCost + EmailCost;
                }
                var advertdetails = item.CampaignAdverts.Where(top => top.CampaignProfileId == item.CampaignProfileId).FirstOrDefault();
                string advertname = string.Empty;
                var advertId = 0;
                if (advertdetails != null)
                {

                    advertname = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertName;
                    advertId = _advertRepository.GetAll().Where(top => top.AdvertId == advertdetails.AdvertId).FirstOrDefault().AdvertId;
                }
                else
                {
                    advertname = "-";
                    advertId = 0;
                }
                _result.Add(new CampaignAdminResult { CampaignProfileId = item.CampaignProfileId, CampaignName = item.CampaignName, AdvertId = advertId, AdvertName = advertname, ClientId = item.ClientId, ClientName = item.Client.Name, CreatedDateTime = item.CreatedDateTime, Email = item.User.Email, UserId = item.UserId, UserName = item.User.FirstName + " " + item.User.LastName, finaltotalplays = finaltotalplays, FundsAvailable = Convert.ToDecimal(item.TotalBudget) - Convert.ToDecimal(totalspend), Status = item.Status, totalaveragebid = Convert.ToDecimal(totalbidval), TotalBudget = item.TotalBudget, totalspend = Convert.ToDecimal(totalspend), TicketCount = _questionRepository.Count(top => top.UserId == userId && top.CampaignProfileId == item.CampaignProfileId) });

            }

            return _result;
        }
        [Route("UpdateStatus")]
        [Route("{id}/{status}")]
        [HttpPost]
        public ActionResult UpdateStatus(int id, int status)
        {

            if (User.Identity.IsAuthenticated)
            {
                CampaignProfileFormModel CampaignProfileFormModel = new CampaignProfileFormModel();
                CreateOrUpdateCampaignProfileCommand command =
                  Mapper.Map<CampaignProfileFormModel, CreateOrUpdateCampaignProfileCommand>(CampaignProfileFormModel);


                command.Status = status;

                var campaigndetails = _profileRepository.GetById(id);
                if (campaigndetails != null)
                {

                    command.StartDate = campaigndetails.StartDate;
                    command.EndDate = campaigndetails.EndDate;
                    command.CampaignProfileId = id;
                    command.UserId = campaigndetails.UserId;
                    command.MaxBid = campaigndetails.MaxBid;
                    command.MaxMonthBudget = campaigndetails.MaxWeeklyBudget;
                    command.MaxWeeklyBudget = campaigndetails.MaxWeeklyBudget;
                    command.MaxHourlyBudget = campaigndetails.MaxHourlyBudget;
                    command.MaxDailyBudget = campaigndetails.MaxDailyBudget;
                    command.CampaignDescription = campaigndetails.CampaignDescription;
                    command.CampaignName = campaigndetails.CampaignName;
                    command.ClientId = campaigndetails.ClientId;
                    command.Active = campaigndetails.Active;
                    command.AvailableCredit = campaigndetails.AvailableCredit;
                    command.CancelledCurrentMonth = campaigndetails.CancelledCurrentMonth;
                    command.CancelledLastMonth = campaigndetails.CancelledLastMonth;
                    command.CancelledToDate = campaigndetails.CancelledToDate;
                    command.CreatedDateTime = campaigndetails.CreatedDateTime;
                    command.EmailToDate = campaigndetails.EmailToDate;
                    command.EmailsCurrentMonth = campaigndetails.EmailsCurrentMonth;
                    command.EmailsLastMonth = campaigndetails.EmailsLastMonth;
                    command.TotalCredit = campaigndetails.TotalCredit;
                    command.SpendToDate = campaigndetails.SpendToDate;
                    command.MaxDailyBudget = campaigndetails.MaxDailyBudget;
                    command.PlaysCurrentMonth = campaigndetails.PlaysCurrentMonth;
                    command.PlaysLastMonth = campaigndetails.PlaysLastMonth;
                    command.PlaysToDate = campaigndetails.PlaysToDate;
                    command.SmsCurrentMonth = campaigndetails.SmsCurrentMonth;
                    command.SmsLastMonth = campaigndetails.SmsLastMonth;
                    command.SmsToDate = campaigndetails.SmsToDate;
                    command.TotalBudget = campaigndetails.TotalBudget;
                    command.UpdatedDateTime = campaigndetails.UpdatedDateTime;
                    command.UserId = campaigndetails.UserId;
                    command.EmailBody = campaigndetails.EmailBody;
                    command.EmailSenderAddress = campaigndetails.EmailSenderAddress;
                    command.EmailSubject = campaigndetails.EmailSubject;
                    command.SmsBody = campaigndetails.SmsBody;
                    command.SmsOriginator = campaigndetails.SmsOriginator;
                    command.CampaignProfileId = id;
                    command.IsAdminApproval = true;
                    ICommandResult result = _commandBus.Submit(command);
                    if (result.Success)
                    {
                        EFMVCDataContex SQLServerEntities = null;

                        var ConnString = ConnectionString.GetConnectionString(campaigndetails.CountryId);
                        if (!string.IsNullOrEmpty(ConnString))
                            SQLServerEntities = new EFMVCDataContex(ConnString);
                        else
                            SQLServerEntities = new EFMVCDataContex();

                        using (SQLServerEntities)
                        {
                            var campaignmatch = SQLServerEntities.CampaignMatch.Where(s => s.MSCampaignProfileId == id).FirstOrDefault();
                            if(campaignmatch != null)
                            {
                                campaignmatch.Status = status;
                                SQLServerEntities.SaveChanges();
                            }
                        }
                        return Json("success");
                    }
                }



                return Json("fail");
            }
            else
            {
                return Json("notauthorise");
            }
        }
        private void FillCampaignDropdown(IEnumerable<CampaignProfileFormModel> campaignProfileFormModels)
        {
            var campaigndropdown = campaignProfileFormModels.Select(top => new
            {
                CampaignName = top.CampaignName,
                CampaignProfileId = top.CampaignProfileId
            }).ToList();
            ViewBag.campaigns = new MultiSelectList(campaigndropdown, "CampaignProfileId", "CampaignName");
        }

        public void FillUserDropdown(int? userId)
        {
            if (userId != null)
            {
                var userdetails = _userRepository.GetAll().Where(top => top.UserId == userId).Select(top => new
                {
                    Name = top.FirstName + " " + top.LastName,
                    UserId = top.UserId,
                }).Take(1000).ToList();
                ViewBag.userdetails = new MultiSelectList(userdetails, "UserId", "Name");
            }
            else
            {
                var userdetails = _userRepository.GetAll().Select(top => new
                {
                    Name = top.FirstName + " " + top.LastName,
                    UserId = top.UserId,
                }).Take(1000).ToList();
                ViewBag.userdetails = new MultiSelectList(userdetails, "UserId", "Name");
            }

        }
        public void FillClientDropdown()
        {

            var clientdetails = _clientRepository.GetAll().Select(top => new
            {
                Name = top.Name,
                // Id = top.Id
                ClientId = top.Id
            }).ToList();
            // ViewBag.client = new MultiSelectList(clientdetails, "Id", "Name");
            ViewBag.client = new MultiSelectList(clientdetails, "ClientId", "Name");
        }
        public void FillAdvertDropdown()
        {

            var advertdetails = _advertRepository.GetAll().Select(top => new
            {
                AdvertName = top.AdvertName,
                AdvertId = top.AdvertId
            }).ToList();
            ViewBag.adverts = new MultiSelectList(advertdetails, "AdvertId", "AdvertName");
        }
        public void FillCampaignStatus(int? userId)
        {
            IEnumerable<Common.CampaignStatus> campaignTypes = Enum.GetValues(typeof(Common.CampaignStatus))
                                                     .Cast<Common.CampaignStatus>();
            var campaignstatus = (from action in campaignTypes
                                  select new
                                  {
                                      Text = action.ToString(),
                                      Value = ((int)action).ToString()
                                  }).ToList();
            if (userId != null)
            {
                ViewBag.CampaignStatusId = new MultiSelectList(campaignstatus, "Value", "Text", new int[] { 4 });
            }
            else
            {
                ViewBag.CampaignStatusId = new MultiSelectList(campaignstatus, "Value", "Text");
            }
        }
        [Route("GetClientsUser")]
        [HttpPost]
        public ActionResult GetClientsUser(int[] userId)
        {
            try
            {


                if (userId != null)
                {

                    var clientdetails = _clientRepository.GetAll().Where(top => userId.Contains((int)(top.UserId))).Select(top => new
                    {
                        Name = top.Name,
                        Id = top.Id
                    }).ToList();
                    return Json(clientdetails);

                }
                else
                {
                    var clientdetails = _clientRepository.GetAll().Select(top => new
                    {
                        Name = top.Name,
                        Id = top.Id
                    }).ToList();
                    return Json(clientdetails);
                }
            }
            catch (Exception)
            {

                return Json("error");
            }
        }
        [Route("GetClientsAdvert")]
        [HttpPost]
        public ActionResult GetClientsAdvert(int[] clientId)
        {
            try
            {


                if (clientId != null)
                {

                    var advertdetails = _advertRepository.GetAll().Where(top => clientId.Contains((int)(top.ClientId))).Select(top => new
                    {
                        Name = top.AdvertName,
                        Id = top.AdvertId
                    }).ToList();
                    return Json(advertdetails);

                }
                else
                {
                    var advertdetails = _advertRepository.GetAll().Select(top => new
                    {
                        Name = top.AdvertName,
                        Id = top.AdvertId
                    }).ToList();
                    return Json(advertdetails);
                }
            }
            catch (Exception)
            {

                return Json("error");
            }
        }
        [Route("GetCampaignAdvert")]
        [HttpPost]
        public ActionResult GetCampaignAdvert(int[] campaignId)
        {
            try
            {


                if (campaignId != null)
                {
                    var advertId = _campaignAdvertRepository.Get(top => campaignId.Contains(top.CampaignProfileId));
                    if (advertId != null)
                    {
                        var advertdetails = _advertRepository.GetAll().Where(top => top.AdvertId == advertId.AdvertId).Select(top => new
                        {
                            Name = top.AdvertName,
                            Id = top.AdvertId
                        }).ToList();
                        return Json(advertdetails);
                    }
                    return Json("nodata");
                }
                else
                {
                    var advertdetails = _advertRepository.GetAll().Select(top => new
                    {
                        Name = top.AdvertName,
                        Id = top.AdvertId
                    }).ToList();
                    return Json(advertdetails);
                }
            }
            catch (Exception)
            {

                return Json("error");
            }
        }
        [Route("GetClientsCampaign")]
        [HttpPost]
        public ActionResult GetClientsCampaign(int[] clientId, int[] userId)
        {
            try
            {

                if (clientId != null)
                {
                    if (clientId != null)
                    {

                        var campaigndetails = _profileRepository.GetAll().Where(top => clientId.Contains((int)(top.ClientId))).Select(top => new
                        {
                            Name = top.CampaignName,
                            Id = top.CampaignProfileId
                        }).ToList();
                        return Json(campaigndetails);

                    }
                    else
                    {
                        var campaigndetails = _profileRepository.GetAll().Select(top => new
                        {
                            Name = top.CampaignName,
                            Id = top.CampaignProfileId
                        }).ToList();
                        return Json(campaigndetails);
                    }
                }
                else
                {
                    if (userId != null)
                    {

                        var campaigndetails = _profileRepository.GetAll().Where(top => userId.Contains((int)(top.UserId))).Select(top => new
                        {
                            Name = top.CampaignName,
                            Id = top.CampaignProfileId
                        }).ToList();
                        return Json(campaigndetails);

                    }
                    else
                    {
                        var campaigndetails = _profileRepository.GetAll().Select(top => new
                        {
                            Name = top.CampaignName,
                            Id = top.CampaignProfileId
                        }).ToList();
                        return Json(campaigndetails);
                    }
                }
            }
            catch (Exception)
            {

                return Json("error");
            }
        }

        [Route("GetUsersCampaign")]
        [HttpPost]
        public ActionResult GetUsersCampaign(int[] userId)
        {
            try
            {


                if (userId != null)
                {

                    var campaigndetails = _profileRepository.GetAll().Where(top => userId.Contains((int)(top.UserId))).Select(top => new
                    {
                        Name = top.CampaignName,
                        Id = top.CampaignProfileId
                    }).ToList();
                    return Json(campaigndetails);

                }
                else
                {
                    var campaigndetails = _profileRepository.GetAll().Select(top => new
                    {
                        Name = top.CampaignName,
                        Id = top.CampaignProfileId
                    }).ToList();
                    return Json(campaigndetails);
                }
            }
            catch (Exception)
            {

                return Json("error");
            }
        }
        [Route("SearchCampaigns")]
        public ActionResult SearchCampaigns([Bind(Prefix = "Item2")]SearchClass.CampaignAdminFilter _filterCritearea, int[] UserId, int[] ClientId, int[] AdvertId, int[] CampaignId, int[] CampaignStatusId)
        {
            ViewBag.SearchResult = true;
            if (User.Identity.IsAuthenticated)
            {
                List<CampaignAdminResult> _result = new List<CampaignAdminResult>();
                var finalresult = new List<CampaignAdminResult>();
                if (_filterCritearea != null)
                {
                    _result = GetCampaignResult(null, null);
                    finalresult = getcampaignResult(_result, _filterCritearea, UserId, ClientId, AdvertId, CampaignId, CampaignStatusId);
                }
                else
                {
                    CampaignStatusId = new int[] { 1 };
                    _result = GetCampaignResult(null, null);
                    finalresult = getcampaignResult(_result, _filterCritearea, UserId, ClientId, AdvertId, CampaignId, CampaignStatusId);
                }

                return PartialView("_UserCampaignDetails", finalresult);
            }
            else
            {
                return PartialView("_UserCampaignDetails", "notauthorise");
            }
        }

        //[Route("CampaignAdvertDetails")]
        //public ActionResult CampaignAdvertDetails(int CampaignProfileId)
        //{
        //    FillCountryList();
        //    ViewBag.CampaignId = CampaignProfileId;
        //    FillCampaignAuditStatus();
        //    FillCampaignAuditSMSStatus();
        //    CampaignProfileMapping _mapping = new CampaignProfileMapping();


        //    CampaignProfileGeographicFormModel CampaignProfileGeographicModel = new CampaignProfileGeographicFormModel();
        //    CampaignProfileDemographicsFormModel CampaignProfileDemographicsmodel = new CampaignProfileDemographicsFormModel();
        //    CampaignProfileAdvertFormModel CampaignProfileAd = new CampaignProfileAdvertFormModel();

        //    CampaignProfileSkizaFormModel CampaignProfileSkizaDetail = new CampaignProfileSkizaFormModel();
           
        //    CampaignProfileMobileFormModel Mobilepro = new CampaignProfileMobileFormModel();
            
        //    CampaignAuditFilter CampaignAuditFilter = new CampaignAuditFilter();
        //    CampaignDashboardChartResult CampaignDashboardChartResult = new CampaignDashboardChartResult();
        //    CampaignAuditFilter.CampaignProfileId = id;
        //    EFMVCUser efmvcUser = System.Web.HttpContext.Current.User.GetEFMVCUser();
        //    User user = _userRepository.GetById(efmvcUser.UserId);
        //    var _clientdetails = _clientRepository.GetMany(x => x.UserId == efmvcUser.UserId && (x.Status == 1 || x.Status == 2));
        //    IEnumerable<ClientModel> clientModels =
        //        Mapper.Map<IEnumerable<Client>, IEnumerable<ClientModel>>(_clientdetails);
        //    FillAddClient(clientModels);
        //    var campaignProfileResult = _profileRepository.GetMany(x => x.CampaignProfileId == id && x.UserId == efmvcUser.UserId && (x.Status != 5));
        //    if (campaignProfileResult.Count() == 0)
        //        return RedirectToAction("Index");

        //    ViewBag.Country = _countryRepository.Get(s => s.Name.ToLower() == "kenya").Name;//ConfigurationManager.AppSettings["Country"];
        //    if (id != 0)
        //    {
        //        //var countryId = campaignProfileResult.FirstOrDefault().CountryId;
        //        //var areaResult = _areaRepository.GetMany(s => s.CountryId == countryId).ToList();
        //        //List<QuestionOptionModel> areaName = new List<QuestionOptionModel>();
        //        //if(areaResult.Count() > 0)
        //        //{
        //        //    areaName = areaResult.Select(s => new QuestionOptionModel { QuestionName = s.AreaName, Selected = false }).ToList();
        //        //}

        //        CampaignProfileGeographicModel = CampaignProfileGeographic(id, CampaignProfileGeographicModel);
        //        //CampaignProfileGeographicModel.AreaQuestion = areaName;
        //        _mapping.CampaignProfileGeographicModel = CampaignProfileGeographicModel;

        //        CampaignProfileDemographicsmodel = CampaignProfileDemographic(id, CampaignProfileDemographicsmodel);
        //        _mapping.CampaignProfileDemographicsmodel = CampaignProfileDemographicsmodel;

        //        CampaignProfileAd = CampaignProfileAdvert(id, CampaignProfileAd);
        //        _mapping.CampaignProfileAd = CampaignProfileAd;

        //        CampaignProfileSkizaDetail = CampaignProfileSkizaInormation(id, CampaignProfileSkizaDetail);
        //        _mapping.CampaignProfileSkizaFormModel = CampaignProfileSkizaDetail;
        //        //CampaignProfileAtt = CampaignProfileAttitude(id, CampaignProfileAtt);
        //        //_mapping.campaignProfileAttitude = CampaignProfileAtt;
        //        //Cinemapro = Cinema(id, Cinemapro);
        //        //_mapping.CampaignProfileCinemaFormModel = Cinemapro;
        //        //Internetpro = Internet(id, Internetpro);
        //        //_mapping.CampaignProfileInternetFormModel = Internetpro;

        //        Mobilepro = Mobile(id, Mobilepro);
        //        _mapping.CampaignProfileMobileFormModel = Mobilepro;

        //        //Presspro = Press(id, Presspro);
        //        //_mapping.CampaignProfilePressFormModel = Presspro;
        //        //ProductServicepro = ProductsServices(id, ProductServicepro);
        //        //_mapping.CampaignProfileProductsServiceFormModel = ProductServicepro;
        //        //Radiopro = Radio(id, Radiopro);
        //        //_mapping.CampaignProfileRadioFormModel = Radiopro;
        //        //Tvpro = Tv(id, Tvpro);
        //        //_mapping.CampaignProfileTvFormModel = Tvpro;
        //        //Timingpro = Timing(id, Timingpro);
        //        //_mapping.CampaignProfileTimeSettingFormModel = Timingpro;


        //        var model = GetEditData(id, efmvcUser.UserId);

        //        ViewBag.AdvertClientId = model.ClientId;
        //        _mapping.AdvertFormModel = advertFormModels();
        //        //_mapping.CampaignAudit = campaignAudit(id); 

        //        _mapping.CampaignAudit = new List<CampaignAuditResult>();
        //        _mapping.CampaignAuditFilter = CampaignAuditFilter;
        //        ViewBag.ClientId = model.ClientId;
        //        ViewBag.CampaignProfileId = model.CampaignProfileId;
        //        if (model != null)
        //            CampaignDashboardChartResult = FillChartDataByCampaignId(model); // Remove this Comment
        //                                                                             //CampaignDashboardChartResult = new CampaignDashboardChartResult();
        //        _mapping.CampaignDashboardChartResult = CampaignDashboardChartResult;

        //        ProfileGeographicOptions(_mapping.CampaignProfileGeographicModel, model.CountryId);
        //        ProfileDemographicsOptions(_mapping.CampaignProfileDemographicsmodel, model.CountryId);
        //        ProfileAdvertOptions(_mapping.CampaignProfileAd, model.CountryId);
        //        ProfileMobileFormOptions(_mapping.CampaignProfileMobileFormModel, model.CountryId);

        //        //CampaignProfileFormModel
        //        return View(Tuple.Create(model, _mapping));
        //    }
        //    else
        //    {
        //        ViewBag.ClientId = null;
        //        ViewBag.CampaignProfileId = null;
        //    }
        //    return View("Index");

        //    return View();
        //}

        public List<CampaignAdminResult> getcampaignResult(List<CampaignAdminResult> campaignresult, SearchClass.CampaignAdminFilter _filterCritearea, int[] UserId, int[] ClientId, int[] AdvertId, int[] CampaignId, int[] CampaignStatusId)
        {
            if (campaignresult != null && _filterCritearea != null)
            {

                if (UserId != null)
                {
                    campaignresult = campaignresult.Where(top => UserId.Contains(top.UserId)).ToList();
                }
                if (ClientId != null)
                {
                    campaignresult = campaignresult.Where(top => ClientId.Contains(top.ClientId)).ToList();
                }
                if (AdvertId != null)
                {
                    campaignresult = campaignresult.Where(top => AdvertId.Contains(top.AdvertId)).ToList();
                }
                if (CampaignId != null)
                {
                    campaignresult = campaignresult.Where(top => CampaignId.Contains(top.CampaignProfileId)).ToList();
                }
                if (CampaignStatusId != null)
                {
                    campaignresult = campaignresult.Where(top => CampaignStatusId.Contains(top.Status)).ToList();
                }
                if ((_filterCritearea.Fromdate != null && _filterCritearea.Todate != null))
                {
                    campaignresult = campaignresult.Where(top => top.CreatedDateTime.Date >= _filterCritearea.Fromdate.Value.Date && top.CreatedDateTime.Date <= _filterCritearea.Todate.Value.Date).ToList();
                }
            }
            else
            {
                if (UserId != null)
                {
                    campaignresult = campaignresult.Where(top => UserId.Contains(top.UserId)).ToList();
                }
                if (CampaignStatusId != null)
                {
                    campaignresult = campaignresult.Where(top => CampaignStatusId.Contains(top.Status)).ToList();
                }
            }
            return campaignresult;
        }
    }
}
